import LoginCompo from "../components/auth";

const Login = () => {
  return <LoginCompo />;
};

export default Login;
