export const GET_REPORT = "GET_REPORT";
export const GET_REPORT_ERROR = "GET_REPORT_ERROR";

export const GET_LOVE = "GET_LOVE";
export const GET_LOVE_ERROR = "GET_LOVE_ERROR";

export const GET_FINANCE = "GET_FINANCE";
export const GET_FINANCE_ERROR = "GET_FINANCE_ERROR";