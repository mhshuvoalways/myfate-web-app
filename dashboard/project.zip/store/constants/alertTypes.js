export const ALERT_TYPE = "ALERT_TYPE";
export const CLEAR_ALERT_TYPE = "CLEAR_ALERT_TYPE";